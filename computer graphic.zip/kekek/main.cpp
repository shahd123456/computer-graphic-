#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>
void display ();
void reshape (int w , int h);
void timer(int);
void init(){
    glClearColor(0.1,0.5,1,0.0);
}
int main (int argc ,char** argv)
{

    glutInit(&argc , argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
    glutInitWindowPosition(200 , 0);
    glutInitWindowSize(1200,800);
    glutCreateWindow("Aya_AlaaEldin 211011099/Shahd_Reda 211010168");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutTimerFunc(0,timer,0);
    init();
    glutMainLoop();
    }

float Animation = 0.0;
float anim=0.0;
GLfloat anglee=45.0f;
int re=1; // in 1 second rotate
void display()
{

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();


    glBegin(GL_LINES); // first 3oshb bel line
    glColor3f(0.3,0,0.4);
    glVertex2f(9,-9);
    glVertex2f(9,-4);
    glVertex2f(9,-5);
    glVertex2f(10,-4);
    glVertex2f(9,-5);
    glVertex2f(8,-4);
    glVertex2f(9,-6);
    glVertex2f(10,-5);
    glVertex2f(9,-6);
    glVertex2f(8,-5);
    glVertex2f(9,-7);
    glVertex2f(10,-6);
    glVertex2f(9,-7);
    glVertex2f(8,-6);
    glVertex2f(9,-8);
    glVertex2f(10,-7);
    glVertex2f(9,-8);
    glVertex2f(8,-7);
    glEnd();
    ////////
    glBegin(GL_LINES); //30sb
    glColor3f(0.3,0,0.4);
    glVertex2f(5,-4);
    glVertex2f(5,-9);
    glEnd();

   glBegin(GL_TRIANGLES);
    glColor3f(0.7,0.6,1);
    glVertex2f(5,-8);
    glVertex2f(6,-7);
    glVertex2f(4,-7);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3f(0.7,0.6,1);
    glVertex2f(5,-7);
    glVertex2f(6,-6);
    glVertex2f(4,-6);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.7,0.4,1);
    glVertex2f(5,-6);
    glVertex2f(6,-5);
    glVertex2f(5,-4);
    glVertex2f(4,-5);
    glEnd();
    ////////////

    glBegin(GL_POLYGON); // el gsm first fish
    glColor3f(1,0.5,1);
    glVertex2f(9+anim,1);
    glVertex2f(7+anim,2);
    glColor3f(1,0.6,0.9);
    glVertex2f(5+anim,1);
    glVertex2f(7+anim,0);
    glColor3f(1,0.5,1);
    glEnd();

    glBegin(GL_POLYGON); // el dra3 el fo2 first fish
    glColor3f(1,0.8,0.9);
    glVertex2f(7+anim,2);
    glVertex2f(8+anim,4);
    glColor3f(1,0.5,1);
    glVertex2f(7+anim,3);
    glVertex2f(6+anim,4);
    glColor3f(1,0.8,0.9);
    glEnd();

    glBegin(GL_POLYGON); // el dra3 el t7tt first fish
    glColor3f(1,0.8,0.9);
    glVertex2f(7+anim,0);
    glVertex2f(8+anim,-2);
     glColor3f(1,0.5,1);
    glVertex2f(7+anim,-1);
    glVertex2f(6+anim,-2);
    glColor3f(1,0.8,0.9);
    glEnd();

    glBegin(GL_POLYGON); // el tail first fish
    glColor3f(1,0.8,0.9);
    glVertex2f(5+anim,1);
    glVertex2f(3+anim,2);
     glColor3f(1,0.5,1);
    glVertex2f(4+anim,1);
    glVertex2f(3+anim,0);
    glColor3f(1,0.8,0.9);
    glEnd();

    int i; // el eye first fish
    double radius22 = 0.14;
    double angle22;
    glBegin(GL_POLYGON);
    glColor3f(0,0,0);
    for(i = 0; i <= 360; i++) {
            angle22 = i * 3.14 / 180;
    glVertex2f(radius22 * cos(angle22)+(8+anim), radius22 * sin(angle22)+1);
}
  glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.6,0.3,0.8); // el gsm second  fish
    glVertex2f(9+anim,7);
    glVertex2f(7+anim,8);
    glColor3f(0.4,0.4,0.7);
    glVertex2f(5+anim,7);
    glVertex2f(7+anim,6);
    glColor3f(0.6,0.6,0.8);
    glEnd();

    glBegin(GL_POLYGON); // el dra3 el fo2 second  fish
    glColor3f(0.6,0.5,0.6);
    glVertex2f(7+anim,8);
    glVertex2f(8+anim,10);
    glColor3f(0.4,0.4,0.7);
    glVertex2f(7+anim,9);
    glVertex2f(6+anim,10);
    glColor3f(0.6,0.3,0.8);
    glEnd();

    glBegin(GL_TRIANGLES); // el dra3 el t7tt second  fish
    glColor3f(0.6,0.5,0.6);
    glVertex2f(7+anim,6);
    glVertex2f(8+anim,5);
    glColor3f(0.4,0.4,0.7);
    glVertex2f(6+anim,5);
    glColor3f(0.6,0.3,0.8);
    glEnd();

    glBegin(GL_POLYGON); // el tail second  fish
    glColor3f(0.6,0.5,0.6);
    glVertex2f(5+anim,7);
    glVertex2f(3+anim,8);
    glColor3f(0.4,0.4,0.7);
    glVertex2f(4+anim,7);
    glVertex2f(3+anim,6);
    glColor3f(0.6,0.3,0.8);
    glEnd();

    int n; // el eye second  fish
    double radius2 = 0.14;
    double angle2;
    glBegin(GL_POLYGON);
    glColor3f(0,0,0);
    for(n = 0; n <= 360; n++) {
            angle2 = n * 3.14 / 180;
    glVertex2f(radius2 * cos(angle2)+(8+anim), radius2 * sin(angle2)+7);
}
     glEnd();

 glPushMatrix();
    glRotatef(anglee,0,0,1);
    int m; // face dofda3a
    double radius3 = 0.6;
    double angle3;
     glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0,0.5,0.2);
    for(m = 0; m <= 360; m++) {
            angle3 = m * 3.14 / 180;
    glVertex2f(radius3 * cos(angle3)+(2), radius3 * sin(angle3)+(-5));
}
    glEnd();
    glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
    int l; // gsm dofda3a
    double radius4 = 0.6;
    double angle4;
     glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0,0.5,0.2);
    for(l = 0; l <= 360; l++) {
            angle4 = l * 3.14 / 180;
    glVertex2f(radius4 * cos(angle4)+(2), radius4 * sin(angle4)+(-6));
}
     glEnd();
       glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
    int x; // el eye dofda3a blue
    double radius5 = 0.3;
    double angle5;
    glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0.8,1,1);
    for(x = 0; x <= 360; x++) {
            angle5 = x * 3.14 / 180;
    glVertex2f(radius5 * cos(angle5)+(1.7), radius5 * sin(angle5)+(-4.6));
}
    glEnd();
        glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
 int y; // el eye dofda3a blue
    double radius6 = 0.3;
    double angle6;
     glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0.8,1,1);
    for(y = 0; y <= 360; y++) {
            angle6 = y * 3.14 / 180;
    glVertex2f(radius6 * cos(angle6)+(2.3), radius6 * sin(angle6)+(-4.6));
} glEnd();
    glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
    int b; // el eye dofda3a soda
    double radius7 = 0.2;
    double angle7;
     glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0,0,0);
    for(b = 0; b <= 360; b++) {
            angle7 = b * 3.14 / 180;
    glVertex2f(radius7 * cos(angle7)+(1.7), radius7 * sin(angle7)+(-4.5));
}
      glEnd();
          glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
      int a; // el eye dofda3a soda
      double radius8 = 0.2;
      double angle8;
      glRotatef(anglee,0.0f,0.0f,1.0f);
      glBegin(GL_POLYGON);
      glColor3f(0,0,0);
      for(a = 0; a <= 360; a++) {
             angle8 = a * 3.14 / 180;
        glVertex2f(radius8 * cos(angle8)+(2.3), radius8 * sin(angle8)+(-4.5));
}
      glEnd();
          glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
      int f; // dofda3a hands
    double radius9 = 0.4;
    double angle9;
    glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0,0.5,0.2);
    for(f = 0; f <= 360; f++) {
            angle9 = f* 3.14 / 180;
       glVertex2f(radius9 * cos(angle9)+(1.5), radius9 * sin(angle9)+(-6));
}
       glEnd();
           glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
       int o; // dofda3a hands
    double radius10 = 0.4;
    double angle10;
     glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0,0.5,0.2);
    for(o = 0; o<= 360; o++) {
            angle10 = o * 3.14 / 180;
       glVertex2f(radius10 * cos(angle10)+(2.5), radius10 * sin(angle10)+(-6));
}
      glEnd();
          glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
    int t; // dofda3a legs
    double radius11 = 0.3;
    double angle11;
    glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0,0.5,0.2);
    for(t = 0; t<= 360; t++) {
            angle11 = t * 3.14 / 180;
       glVertex2f(radius11 * cos(angle11)+(2.4), radius11 * sin(angle11)+(-6.5));
}
      glEnd();
          glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
    int r; // dofda3a legs
    double radius12 = 0.3;
    double angle12;
    glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0,0.5,0.2);
    for(r = 0; r<= 360; r++) {
            angle12 = r * 3.14 / 180;
       glVertex2f(radius12 * cos(angle12)+(1.6), radius12 * sin(angle12)+(-6.5));
}
       glEnd();
           glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
    int w; // dofda3a mouth
    double radius13 = 0.3;
    double angle13;
     glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0.8,1,1);
    for(w = 180; w<= 360; w++) {
            angle13 = w * 3.14 / 180;
       glVertex2f(radius13 * cos(angle13)+(2), radius13 * sin(angle13)+(-5));
}
    glEnd();
        glLoadIdentity();
    glPopMatrix();

glPushMatrix();
    glRotatef(anglee,0,0,1);
 int q; // dofda3a lasan red
    double radius14 = 0.2;
    double angle14;
    glRotatef(anglee,0.0f,0.0f,1.0f);
    glBegin(GL_POLYGON);
    glColor3f(0.7,0.1,0);
    for(q = 180; q<= 360; q++) {
            angle14 = q * 3.14 / 180;
       glVertex2f(radius14 * cos(angle14)+(2), radius14 * sin(angle14)+(-5.1));

    }
    glEnd();
    glLoadIdentity();
    glPopMatrix();


    glBegin(GL_POLYGON);// el gsm third fish
    glColor3f(0.8,0.5,0);
    glVertex2f(-9+Animation,7);
    glColor3f(0.8,0.7,0.7);
    glVertex2f(-7+Animation,8);
    glVertex2f(-5+Animation,7);
    glColor3f(0.8,0.5,0);
    glVertex2f(-7+Animation,6);
    glColor3f(0.8,0.7,0.7);
    glEnd();

    glBegin(GL_POLYGON); // el dra3 el fo2 third fish
    glColor3f(0.8,0.5,0.3);
    glVertex2f(-7+Animation,8);
    glColor3f(0.8,0.6,0.2);
    glVertex2f(-6+Animation,10);
    glVertex2f(-7+Animation,9);
    glColor3f(0.8,0.5,0.3);
    glVertex2f(-8+Animation,10);
    glColor3f(0.8,0.6,0.2);
    glEnd();

    glBegin(GL_TRIANGLES); // el dra3 el t7tt third  fish
    glColor3f(0.8,0.5,0.3);
    glVertex2f(-7+Animation,6);
    glVertex2f(-8+Animation,5);
    glColor3f(0.8,0.6,0.2);
    glVertex2f(-6+Animation,5);
    glColor3f(0.8,0.5,0.3);
    glEnd();

    glBegin(GL_POLYGON); // el tail third  fish
    glColor3f(0.8,0.5,0.3);
    glVertex2f(-5+Animation,7);
    glColor3f(0.8,0.6,0.2);
    glVertex2f(-3+Animation,8);
    glVertex2f(-4+Animation,7);
    glColor3f(0.8,0.5,0.3);
    glVertex2f(-3+Animation,6);
    glColor3f(0.8,0.6,0.2);
    glEnd();

    int d; // el eye third  fish
    double radius15 = 0.14;
    double angle15;
    glBegin(GL_POLYGON);
    glColor3f(0,0,0);
    for(d = 0; d <= 360; d++) {
            angle15 = d * 3.14 / 180;
    glVertex2f(radius15 * cos(angle15)+(-8+Animation), radius15 * sin(angle15)+7);
}
     glEnd();
    glBegin(GL_POLYGON);
    glColor3f(0.7,0,0.1); // el gsm fourth  fish
    glVertex2f(-9+Animation,-1);
    glVertex2f(-5+Animation,0);
    glColor3f(0.2,0.4,0);
    glVertex2f(1+Animation,-1);
    glVertex2f(-5+Animation,-2);
    glColor3f(0.2,0.4,0);
    glEnd();

    glBegin(GL_POLYGON); // el dra3 el fo2 fourth  fish
    glColor3f(0,0,0);
    glVertex2f(-5+Animation,0);
    glVertex2f(-4+Animation,3);
    glColor3f(0.7,0,0.1);
    glVertex2f(-5+Animation,2);
    glVertex2f(-6+Animation,2);
    glColor3f(0.2,0.4,0);
    glEnd();

    glBegin(GL_POLYGON); // el dra3 el t7tt fourth  fish
    glColor3f(0,0,0);
    glVertex2f(-5+Animation,-2);
    glVertex2f(-3+Animation,-4);
    glColor3f(0.7,0,0.1);
    glVertex2f(-5+Animation,-3);
    glVertex2f(-7+Animation,-3);
    glColor3f(0.2,0.4,0);
    glEnd();

    glBegin(GL_POLYGON); // el tail fourth  fish
    glColor3f(0,0,0);
    glVertex2f(1+Animation,-1);
    glVertex2f(3+Animation,1);
    glColor3f(0.7,0,0.1);
    glVertex2f(2+Animation,-1);
    glVertex2f(3+Animation,-3);
    glColor3f(0.2,0.4,0);
    glEnd();

    int c; // el eye fourth fish
    double radius16 = 0.14;
    double angle16;
    glBegin(GL_POLYGON);
    glColor3f(0,0,0);
    for(c = 0; c <= 360; c++) {
            angle16 = c * 3.14 / 180;
    glVertex2f(radius16 * cos(angle16)+(-7)+Animation, radius16 * sin(angle16)+(-1));
}
     glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(7,-9);
    glVertex2f(9,-5);
    glColor3f(0,0.9,0.3);
    glVertex2f(8,-5);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(7,-9);
    glVertex2f(8,-5);
    glColor3f(0,0.9,0.3);
    glVertex2f(7,-5);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(7,-9);
    glVertex2f(7,-5);
    glColor3f(0,0.9,0.3);
    glVertex2f(6,-5);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(7,-9);
    glVertex2f(6,-5);
    glColor3f(0,0.9,0.3);
    glVertex2f(5,-5);
    glColor3f(0,0.7,0);
    glEnd();
       //////
    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(2,-10);
    glVertex2f(4,-7);
    glColor3f(0,0.9,0.3);
    glVertex2f(3,-7);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(2,-10);
    glVertex2f(3,-7);
    glColor3f(0,0.9,0.3);
    glVertex2f(2,-7);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(2,-10);
    glVertex2f(2,-7);
    glColor3f(0,0.9,0.3);
    glVertex2f(1,-7);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(2,-10);
    glVertex2f(1,-7);
    glColor3f(0,0.9,0.3);
    glVertex2f(0,-7);
    glColor3f(0,0.7,0);
    glEnd();
    ////////

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(-3,-9);
    glVertex2f(-1,-5);
    glColor3f(0,0.9,0.3);
    glVertex2f(-2,-5);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(-3,-9);
    glVertex2f(-2,-5);
    glColor3f(0,0.9,0.3);
    glVertex2f(-3,-5);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(-3,-9);
    glVertex2f(-3,-5);
    glColor3f(0,0.9,0.3);
    glVertex2f(-4,-5);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(-3,-9);
    glVertex2f(-4,-5);
    glColor3f(0,0.9,0.3);
    glVertex2f(-5,-5);
    glColor3f(0,0.7,0);
    glEnd();
    /////////
    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(-8,-9);
    glVertex2f(-6,-7);
    glColor3f(0,0.9,0.3);
    glVertex2f(-7,-7);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(-8,-9);
    glVertex2f(-7,-7);
    glColor3f(0,0.9,0.3);
    glVertex2f(-8,-7);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(-8,-9);
    glVertex2f(-8,-7);
    glColor3f(0,0.9,0.3);
    glVertex2f(-9,-7);
    glColor3f(0,0.7,0);
    glEnd();

    glBegin(GL_TRIANGLES); // 3oshb
    glColor3f(0,0.4,0.3);
    glVertex2f(-8,-9);
    glVertex2f(-9,-7);
    glColor3f(0,0.9,0.3);
    glVertex2f(-10,-7);
    glColor3f(0,0.7,0);
    glEnd();

    int p; // s5ooorr
    double radius23 = 0.5;
    double angle23;
    glBegin(GL_POLYGON);
    glColor3f(0.8,0.4,0.2);
    for(p = 0; p <= 360; p++) {
            angle23 = p * 3.14 / 180;
    glVertex2f(radius23 * cos(angle23)+0, radius23 * sin(angle23)+(-8));
}
  glEnd();

      int z; // s5ooorr
    double radius24 = 0.5;
    double angle24;
    glBegin(GL_POLYGON);
    glColor3f(0.8,0.4,0.2);
    for(z= 0; z <= 360; z++) {
            angle24 = z * 3.14 / 180;
    glVertex2f(radius24 * cos(angle24)+0, radius24 * sin(angle24)+(-9));
}
  glEnd();

    int v; // s5ooorr
    double radius25 = 0.5;
    double angle25;
    glBegin(GL_POLYGON);
    glColor3f(0.8,0.4,0.2);
    for(v= 0; v <= 360; v++) {
            angle25 = v * 3.14 / 180;
    glVertex2f(radius25 * cos(angle25)+(-1), radius25 * sin(angle25)+(-9));
}
  glEnd();
   int h; // s5ooorr
    double radius26 = 0.5;
    double angle26;
    glBegin(GL_POLYGON);
    glColor3f(0.8,0.4,0.2);
    for(h= 0; h <= 360; h++) {
            angle26 = h * 3.14 / 180;
    glVertex2f(radius26 * cos(angle26)+(-1), radius26 * sin(angle26)+(-8));
}
  glEnd();

    glBegin(GL_POLYGON);  // 3oshb bardo
    glColor3f(1,1,0.1);
    glVertex2f(-5,-10);
    glVertex2f(-4,-9);
    glColor3f(1,0.7,0);
    glVertex2f(-5,-8);
    glVertex2f(-6,-9);
    glColor3f(1,1,0.7);
    glEnd();
    glPopMatrix();

    glutSwapBuffers();
    anglee+=0.2;
    //glFlush();

}


void reshape(int w , int h)
{
    glViewport(0,0 ,(GLsizei)w , (GLsizei)h  );
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-10 , 10 , -10 , 10);
    glMatrixMode(GL_MODELVIEW);
}
void timer(int)
{
    glutPostRedisplay();
    glutTimerFunc(re,timer,0);


    Animation += -0.01;
    anim +=0.01;

}


